./COVID_JAVA/run.sh & 
./COVID_REACT/run.sh 


