cd ~/COVID_JAVA
mvn clean package
mvn spring-boot:run

