cd ~/COVID_REACT/my-app
npm start
